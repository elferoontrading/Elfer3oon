# 🚀 Quick Start Guide - EL FER3OON TRADING

Get your backend and admin panel running in 5 minutes!

## ⚡ Backend Setup (5 minutes)

### Step 1: Create Project Structure
```bash
mkdir el-fer3oon-backend
cd el-fer3oon-backend

# Create folders
mkdir -p config middleware routes services public/admin database scripts
```

### Step 2: Copy Files
Copy all backend files to their respective folders:
```
el-fer3oon-backend/
├── package.json
├── .env
├── server.js
├── config/database.js
├── middleware/auth.js
├── routes/
│   ├── auth.js
│   ├── accounts.js
│   ├── signals.js
│   └── admin.js
├── services/signalGenerator.js
├── scripts/initDatabase.js
└── public/admin/index.html
```

### Step 3: Install Dependencies
```bash
npm install
```

### Step 4: Configure Environment
Edit `.env`:
```env
# IMPORTANT: Change these values!
ADMIN_USERNAME=admin
ADMIN_PASSWORD=YourSecurePassword123!
JWT_SECRET=change-this-to-random-string-xyz123
API_KEY=change-this-to-your-api-key-xyz789
```

### Step 5: Initialize Database
```bash
npm run init-db
```

### Step 6: Start Server
```bash
npm start
```

✅ **Backend is now running at `http://localhost:3000`**

## 🎯 Admin Panel Access

1. Open browser: `http://localhost:3000/admin`
2. Login with credentials from `.env`
3. You'll see the dashboard!

## 📱 Flutter App Integration

### Step 1: Add HTTP Package
In `pubspec.yaml`:
```yaml
dependencies:
  http: ^1.1.0
```

Run:
```bash
flutter pub get
```

### Step 2: Add API Service
Copy `lib/services/api_service.dart` to your Flutter project

### Step 3: Update API Configuration
In `api_service.dart`, update:
```dart
static const String baseUrl = 'http://YOUR_IP:3000/api';
static const String apiKey = 'YOUR_API_KEY_FROM_ENV';
```

**Finding Your IP:**
- Windows: `ipconfig` → IPv4 Address
- Mac/Linux: `ifconfig` → inet
- Example: `http://192.168.1.100:3000/api`

### Step 4: Update Storage Service
In `lib/services/storage_service.dart`, add:
```dart
// Session token
static Future<void> setSessionToken(String token) async {
  await _prefs.setString('session_token', token);
}

static String getSessionToken() {
  return _prefs.getString('session_token') ?? '';
}
```

### Step 5: Update Auth Service
In `lib/services/auth_service.dart`, change `'ACTIVE'` to `'APPROVED'`:
```dart
bool get isActive => _status == 'APPROVED' && _passKey.isNotEmpty;
```

### Step 6: Integrate API Calls
Update `lib/screens/uid_input_screen.dart`:
```dart
import '../services/api_service.dart';

// In _submitUid method:
void _submitUid() async {
  if (!_formKey.currentState!.validate()) return;
  
  setState(() {
    _isLoading = true;
  });
  
  final uid = _uidController.text.trim();
  final deviceId = StorageService.getDeviceId();
  
  // Call backend API
  final result = await ApiService.register(uid, deviceId);
  
  if (result['success']) {
    // Save to local storage
    final authService = Provider.of<AuthService>(context, listen: false);
    await authService.registerUid(uid);
    
    if (!mounted) return;
    
    if (result['status'] == 'APPROVED') {
      // Already approved - go to trading
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const MainTradingScreen()),
      );
    } else {
      // Pending - go to pending screen
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const PendingScreen()),
      );
    }
  } else {
    // Show error
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(result['error'] ?? 'Registration failed')),
    );
  }
  
  setState(() {
    _isLoading = false;
  });
}
```

### Step 7: Add Heartbeat in Trading Screen
In `lib/screens/main_trading_screen.dart`:
```dart
import 'dart:async';
import '../services/api_service.dart';

Timer? _heartbeatTimer;

@override
void initState() {
  super.initState();
  _initializeWebView();
  _startSignalTimer();
  _startHeartbeat(); // Add this
}

void _startHeartbeat() {
  _heartbeatTimer = Timer.periodic(const Duration(seconds: 30), (timer) async {
    final result = await ApiService.sendHeartbeat();
    
    if (!result['success'] || result['status'] == 'BLOCKED') {
      // Account blocked or session invalid
      timer.cancel();
      if (!mounted) return;
      
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const PendingScreen()),
      );
    }
  });
}

@override
void dispose() {
  _signalTimer?.cancel();
  _heartbeatTimer?.cancel(); // Add this
  super.dispose();
}
```

### Step 8: Update Signal Button
In trading screen, replace mock signal with API call:
```dart
void _sendSignal() async {
  if (!_canSendSignal) return;
  
  setState(() {
    _canSendSignal = false;
  });
  
  final result = await ApiService.getLatestSignal();
  
  if (result['success']) {
    String signal = result['signal']; // UP or DOWN
    double confidence = result['confidence'];
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Signal: $signal'),
        content: Text('Confidence: ${confidence.toStringAsFixed(1)}%\n'
                     'Trend: ${result['trend']}\n'
                     'RSI: ${result['rsi']}'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  } else {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(result['error'] ?? 'Failed to get signal')),
    );
  }
}
```

## ✅ Testing the Integration

### Test 1: Registration
1. Run Flutter app
2. Enter a test UID (e.g., "12345678")
3. App should show "Pending" screen
4. Check admin panel - you should see the account as PENDING

### Test 2: Approval
1. In admin panel, click "Approve" on the account
2. Copy the generated PassKey
3. In Flutter app, the status check should detect approval
4. App should navigate to Trading Screen automatically

### Test 3: Signals
1. On Trading Screen, wait for signal button to activate
2. Click "GET SIGNAL"
3. Should see signal from backend (UP/DOWN with confidence)

### Test 4: Multi-Device Block
1. Note your Device ID in pending screen
2. Change Device ID in storage (or use different device)
3. Try to login with same UID
4. Should be automatically BLOCKED

## 🔧 Common Issues

### Backend won't start
```bash
# Check if port 3000 is in use
lsof -i :3000  # Mac/Linux
netstat -ano | findstr :3000  # Windows

# Use different port in .env
PORT=3001
```

### Flutter can't connect
```bash
# Make sure both are on same network
# Check IP address is correct
# On Android emulator, use: 10.0.2.2:3000
# On iOS simulator, use: localhost:3000
# On real device, use: 192.168.x.x:3000
```

### Admin panel not loading
```bash
# Check public/admin/index.html exists
# Clear browser cache
# Check browser console for errors
```

## 📊 Monitoring

### View Server Logs
```bash
# If using PM2
pm2 logs el-fer3oon

# If running directly
# Logs appear in terminal
```

### Check Database
```bash
sqlite3 database/el_fer3oon.db

# View accounts
SELECT * FROM accounts;

# View recent signals
SELECT * FROM signals ORDER BY candle_time DESC LIMIT 10;

# View activity log
SELECT * FROM activity_log ORDER BY timestamp DESC LIMIT 20;

# Exit
.quit
```

### Test API Endpoints
```bash
# Health check
curl http://localhost:3000/health

# Register (requires API key)
curl -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -H "X-API-Key: YOUR_API_KEY" \
  -d '{"uid":"test123","device_id":"device-uuid"}'
```

## 🎯 Next Steps

1. ✅ Test full flow (register → approve → trading → signals)
2. ✅ Secure `.env` file (never commit to git)
3. ✅ Setup SSL certificate for production
4. ✅ Configure backup strategy
5. ✅ Monitor server resources
6. ✅ Setup alerting for errors

## 🔐 Security Checklist

- [ ] Changed default admin password
- [ ] Changed JWT_SECRET
- [ ] Changed API_KEY
- [ ] Configured firewall rules
- [ ] Setup HTTPS (SSL)
- [ ] Regular database backups
- [ ] Monitoring enabled
- [ ] Rate limiting configured

## 📞 Support

Stuck? Check:
1. README.md for detailed docs
2. Server logs for errors
3. Browser console for frontend issues
4. Database for data verification

---

**You're all set! 🚀 Start trading with EL FER3OON!**