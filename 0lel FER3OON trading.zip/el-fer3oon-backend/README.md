# EL FER3OON TRADING - Backend & Admin Panel

Complete backend API system with Admin Control Panel and Advanced Signal Generation for the EL FER3OON TRADING Flutter application.

## 🚀 Features

### Backend API
- ✅ **REST API** with JWT authentication
- ✅ **Session Token Management** (7-day expiry)
- ✅ **Single Device Enforcement** - automatic blocking on multi-device access
- ✅ **Account Status System** (PENDING → APPROVED → BLOCKED)
- ✅ **Heartbeat Monitoring** every 20-30 seconds
- ✅ **PassKey Generation** for account activation
- ✅ **Automatic Violation Detection**
- ✅ **Activity Logging** for all actions

### Admin Control Panel
- 🎯 **Secure Web Dashboard** with login
- 📊 **Real-time Statistics** (Total, Pending, Approved, Blocked, Active)
- 👥 **Account Management**
  - Approve pending accounts
  - Block/unblock accounts
  - Reset device (allow new device)
  - View detailed account info
  - Delete accounts
- 📈 **Activity Monitoring**
  - Last heartbeat tracking
  - Device history
  - Action logs
- 🔑 **PassKey Management**
  - Auto-generate on approval
  - Copy to clipboard
  - Manual distribution

### Advanced Signal System
- 📡 **One signal per minute** aligned with candle start
- 📊 **Technical Indicators**:
  - RSI (Relative Strength Index)
  - EMA (12 & 26 period)
  - Trend Detection
  - Candle Pattern Analysis
- 🎯 **Signal Types**: UP / DOWN
- 💯 **Confidence Score** (50-95%)
- 📈 **Signal History & Statistics**

## 📁 Project Structure

```
el-fer3oon-backend/
├── server.js                    # Main server entry point
├── package.json                 # Dependencies
├── .env                         # Environment configuration
├── config/
│   └── database.js             # SQLite database setup
├── middleware/
│   └── auth.js                 # Authentication middleware
├── routes/
│   ├── auth.js                 # Authentication routes
│   ├── accounts.js             # Account management routes
│   ├── signals.js              # Signal generation routes
│   └── admin.js                # Admin panel routes
├── services/
│   └── signalGenerator.js      # Advanced signal logic
├── public/
│   └── admin/
│       └── index.html          # Admin panel interface
└── database/
    └── el_fer3oon.db          # SQLite database (auto-created)
```

## ⚙️ Installation

### Prerequisites
- Node.js 16+ installed
- Port 3000 available (or configure different port)

### Step 1: Install Dependencies
```bash
cd el-fer3oon-backend
npm install
```

### Step 2: Configure Environment
Edit `.env` file:
```env
# Change these values for production!
ADMIN_USERNAME=admin
ADMIN_PASSWORD=YourSecurePassword123!
JWT_SECRET=your-super-secret-jwt-key-change-this
API_KEY=your-api-key-for-mobile-app
```

### Step 3: Initialize Database
```bash
npm run init-db
```

### Step 4: Start Server
```bash
# Production
npm start

# Development (with auto-reload)
npm run dev
```

Server will start at: `http://localhost:3000`

## 🔐 API Endpoints

### Authentication Endpoints

#### POST `/api/auth/register`
Register or login with UID and Device ID
```json
Request:
{
  "uid": "12345678",
  "device_id": "uuid-device-id"
}

Response (Pending):
{
  "status": "PENDING",
  "message": "Account created. Waiting for admin approval.",
  "uid": "12345678",
  "device_id": "uuid-device-id"
}

Response (Approved):
{
  "status": "APPROVED",
  "session_token": "jwt-token-here",
  "pass_key": "passkey-here",
  "message": "Login successful"
}

Response (Blocked):
{
  "status": "BLOCKED",
  "error": "Account blocked: Multiple device access detected",
  "message": "Contact support to reset your device"
}
```

#### POST `/api/auth/verify-passkey`
Verify PassKey for account activation
```json
Request:
{
  "uid": "12345678",
  "device_id": "uuid-device-id",
  "pass_key": "generated-passkey"
}

Response:
{
  "verified": true,
  "status": "APPROVED",
  "session_token": "jwt-token-here"
}
```

#### POST `/api/auth/heartbeat`
Keep session alive (requires session token)
```json
Headers:
{
  "Authorization": "Bearer <session_token>",
  "X-API-Key": "<api_key>"
}

Response:
{
  "status": "APPROVED",
  "heartbeat": "OK",
  "timestamp": 1234567890
}
```

#### GET `/api/auth/status`
Check account status (requires session token)
```json
Response:
{
  "status": "APPROVED",
  "has_passkey": true,
  "last_heartbeat": 1234567890
}
```

### Signal Endpoints

#### GET `/api/signals/latest`
Get latest trading signal (requires session token)
```json
Response:
{
  "signal": "UP",
  "asset": "QUOTEX",
  "expiry": "1m",
  "confidence": 75.5,
  "trend": "BULLISH",
  "rsi": 65.32,
  "ema_trend": "BULLISH",
  "timestamp": 1234567890,
  "indicators": {
    "rsi": 65.32,
    "ema12": 1025.45,
    "ema26": 1018.32,
    "candle_pattern": "STRONG_BULL",
    "trend": "BULLISH"
  }
}
```

#### GET `/api/signals/history?limit=20`
Get signal history
```json
Response:
{
  "signals": [
    {
      "signal": "UP",
      "asset": "QUOTEX",
      "confidence": 75.5,
      "trend": "BULLISH",
      "rsi": 65.32,
      "timestamp": 1234567890
    }
  ]
}
```

#### GET `/api/signals/stats`
Get signal statistics (last 24 hours)
```json
Response:
{
  "last_24h": {
    "total": 1440,
    "up": 720,
    "down": 720,
    "avg_confidence": 72.5
  }
}
```

### Admin Endpoints

#### POST `/api/admin/login`
Admin login
```json
Request:
{
  "username": "admin",
  "password": "password"
}

Response:
{
  "success": true,
  "token": "admin-jwt-token",
  "username": "admin"
}
```

#### GET `/api/admin/dashboard`
Get dashboard statistics
```json
Response:
{
  "stats": {
    "total": 100,
    "pending": 10,
    "approved": 85,
    "blocked": 5,
    "active_now": 42
  },
  "recent_activity": [...],
  "recent_signals": [...]
}
```

#### GET `/api/admin/accounts`
Get all accounts (optional: `?status=PENDING`)

#### POST `/api/admin/accounts/:uid/approve`
Approve account and generate PassKey

#### POST `/api/admin/accounts/:uid/block`
Block account
```json
Request:
{
  "reason": "Violation reason"
}
```

#### POST `/api/admin/accounts/:uid/reset-device`
Reset device for account

#### DELETE `/api/admin/accounts/:uid`
Delete account permanently

## 🎯 Admin Panel

Access at: `http://localhost:3000/admin`

### Features:
- 🔐 Secure login
- 📊 Real-time dashboard
- 👥 Account management
- 🔍 Filter by status (All, Pending, Approved, Blocked)
- 📱 Device management
- 🔑 PassKey generation and display
- 📈 Activity monitoring

### Default Credentials:
- **Username**: `admin` (from .env)
- **Password**: Set in `.env` file

**⚠️ IMPORTANT: Change these in production!**

## 🔒 Security Features

### API Protection
- ✅ API Key authentication for mobile app
- ✅ JWT token for session management
- ✅ Rate limiting (100 requests per 15 min)
- ✅ Helmet.js security headers
- ✅ CORS configuration

### Account Security
- ✅ Single device enforcement
- ✅ Automatic blocking on violations
- ✅ PassKey requirement for activation
- ✅ Session token expiry (7 days)
- ✅ Heartbeat timeout monitoring

### Admin Security
- ✅ Separate admin authentication
- ✅ Activity logging
- ✅ Device history tracking

## 📱 Flutter App Integration

### Step 1: Update API URL
In `lib/services/api_service.dart`:
```dart
static const String baseUrl = 'http://YOUR_SERVER_IP:3000/api';
static const String apiKey = 'YOUR_API_KEY_FROM_ENV';
```

### Step 2: Add HTTP Package
In `pubspec.yaml`:
```yaml
dependencies:
  http: ^1.1.0
```

### Step 3: Register on App Launch
In your registration flow:
```dart
final result = await ApiService.register(uid, deviceId);

if (result['status'] == 'APPROVED') {
  // Navigate to Trading Screen
} else if (result['status'] == 'PENDING') {
  // Navigate to Pending Screen
} else if (result['status'] == 'BLOCKED') {
  // Show blocked message
}
```

### Step 4: Implement Heartbeat
In your Trading Screen:
```dart
Timer.periodic(Duration(seconds: 30), (timer) async {
  final result = await ApiService.sendHeartbeat();
  
  if (!result['success'] || result['status'] == 'BLOCKED') {
    // Logout and navigate to pending/blocked screen
  }
});
```

### Step 5: Get Signals
```dart
final signal = await ApiService.getLatestSignal();

if (signal['success']) {
  String direction = signal['signal']; // UP or DOWN
  double confidence = signal['confidence'];
  // Display signal in UI
}
```

## 🔧 Database Schema

### accounts
```sql
- id (INTEGER PRIMARY KEY)
- uid (TEXT UNIQUE)
- device_id (TEXT)
- pass_key (TEXT)
- status (TEXT) - PENDING/APPROVED/BLOCKED
- session_token (TEXT)
- last_heartbeat (INTEGER timestamp)
- created_at (INTEGER timestamp)
- updated_at (INTEGER timestamp)
- blocked_reason (TEXT)
- approved_at (INTEGER timestamp)
- approved_by (TEXT)
```

### signals
```sql
- id (INTEGER PRIMARY KEY)
- signal_type (TEXT) - UP/DOWN
- asset (TEXT)
- expiry (TEXT)
- confidence (REAL)
- indicators (TEXT JSON)
- candle_time (INTEGER timestamp)
- trend (TEXT)
- rsi (REAL)
- ema_trend (TEXT)
- created_at (INTEGER timestamp)
```

### device_history
```sql
- id (INTEGER PRIMARY KEY)
- uid (TEXT)
- device_id (TEXT)
- action (TEXT)
- timestamp (INTEGER)
- ip_address (TEXT)
```

### activity_log
```sql
- id (INTEGER PRIMARY KEY)
- action (TEXT)
- uid (TEXT)
- admin_user (TEXT)
- details (TEXT)
- timestamp (INTEGER)
```

## 🚀 Deployment

### Deploy to VPS/Cloud Server

1. **Install Node.js**
```bash
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs
```

2. **Clone/Upload Project**
```bash
cd /var/www
git clone your-repo.git el-fer3oon-backend
cd el-fer3oon-backend
npm install --production
```

3. **Configure Environment**
```bash
nano .env
# Update all production values
```

4. **Use PM2 for Process Management**
```bash
sudo npm install -g pm2
pm2 start server.js --name el-fer3oon
pm2 save
pm2 startup
```

5. **Configure Firewall**
```bash
sudo ufw allow 3000
```

6. **Setup Nginx Reverse Proxy** (Optional)
```nginx
server {
    listen 80;
    server_name your-domain.com;
    
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

## 📊 Monitoring

### View Logs
```bash
pm2 logs el-fer3oon
```

### Monitor Performance
```bash
pm2 monit
```

### Database Backup
```bash
cp database/el_fer3oon.db database/backup-$(date +%Y%m%d).db
```

## 🔧 Troubleshooting

### Issue: Database not initializing
**Solution**: Run `npm run init-db`

### Issue: Admin can't login
**Solution**: Check `.env` credentials, restart server

### Issue: Mobile app can't connect
**Solution**: 
- Check API_KEY matches in both app and backend
- Verify server IP and port
- Check firewall rules

### Issue: Signals not generating
**Solution**: Check logs, verify signal generator service

## 📝 API Flow Example

```
1. User installs app → Auto-generates Device ID
2. User enters UID → App calls /api/auth/register
3. Backend creates account with status=PENDING
4. Admin approves in panel → Generates PassKey
5. User contacts support → Receives PassKey
6. App calls /api/auth/verify-passkey → Gets session token
7. App navigates to Trading Screen
8. Every 30s: App sends heartbeat
9. Every minute: App requests signal from /api/signals/latest
10. Backend checks: same device + valid session → Returns signal
11. If different device detected → Automatic BLOCK
```

## 🎯 Future Enhancements

- [ ] Email notifications for approvals
- [ ] Telegram bot integration
- [ ] Real-time WebSocket signals
- [ ] Multi-asset support
- [ ] Machine learning for signal accuracy
- [ ] Performance analytics dashboard
- [ ] Automated account verification
- [ ] Mobile admin app

## 📞 Support

For issues or questions:
- Check logs: `pm2 logs`
- Review database: `sqlite3 database/el_fer3oon.db`
- Contact: [@EL_FER3OON](http://t.me/EL_FER3OON)

## 📜 License

Proprietary - All rights reserved

---

**Built with ❤️ for EL FER3OON TRADING**