require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');

// Import routes
const authRoutes = require('./routes/auth');
const accountRoutes = require('./routes/accounts');
const signalRoutes = require('./routes/signals');
const adminRoutes = require('./routes/admin');

// Import middleware
const { apiKeyAuth } = require('./middleware/auth');

const app = express();
const PORT = process.env.PORT || 3000;

// Security middleware
app.use(helmet({
  contentSecurityPolicy: false, // Allow inline scripts for admin panel
}));

// CORS configuration
app.use(cors({
  origin: '*', // Configure appropriately for production
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-API-Key']
}));

// Body parser
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Logging
if (process.env.NODE_ENV !== 'production') {
  app.use(morgan('dev'));
}

// Rate limiting
const limiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW) || 15 * 60 * 1000,
  max: parseInt(process.env.RATE_LIMIT_MAX) || 100,
  message: 'Too many requests from this IP, please try again later.'
});

app.use('/api/', limiter);

// Serve static files for admin panel
app.use('/admin', express.static('public/admin'));

// Health check
app.get('/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    timestamp: new Date().toISOString(),
    service: 'EL FER3OON TRADING API'
  });
});

// API Routes (protected by API Key)
app.use('/api/auth', apiKeyAuth, authRoutes);
app.use('/api/accounts', apiKeyAuth, accountRoutes);
app.use('/api/signals', apiKeyAuth, signalRoutes);

// Admin Routes (separate authentication)
app.use('/api/admin', adminRoutes);

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Endpoint not found' });
});

// Error handler
app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(err.status || 500).json({
    error: err.message || 'Internal server error'
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`
╔════════════════════════════════════════════╗
║   EL FER3OON TRADING - Backend Server     ║
╚════════════════════════════════════════════╝
  
  🚀 Server running on port ${PORT}
  🌍 Environment: ${process.env.NODE_ENV || 'development'}
  🔐 API Key protection: ENABLED
  📊 Admin Panel: http://localhost:${PORT}/admin
  ⚡ API Endpoint: http://localhost:${PORT}/api
  
  Ready to accept connections...
  `);
});

module.exports = app;