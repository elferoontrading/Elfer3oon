require('dotenv').config();
const { initializeDatabase } = require('../config/database');

console.log('Initializing EL FER3OON TRADING database...\n');

try {
  initializeDatabase();
  console.log('\n✅ Database initialized successfully!');
  console.log('\nDatabase location:', process.env.DATABASE_PATH || './database/el_fer3oon.db');
  console.log('\nYou can now start the server with: npm start');
  process.exit(0);
} catch (error) {
  console.error('\n❌ Database initialization failed:', error);
  process.exit(1);
}