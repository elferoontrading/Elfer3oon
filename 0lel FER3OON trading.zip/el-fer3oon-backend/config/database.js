const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

// Ensure database directory exists
const dbDir = path.dirname(process.env.DATABASE_PATH || './database/el_fer3oon.db');
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

const db = new Database(process.env.DATABASE_PATH || './database/el_fer3oon.db');

// Enable foreign keys
db.pragma('foreign_keys = ON');

// Initialize database schema
function initializeDatabase() {
  // Accounts table
  db.exec(`
    CREATE TABLE IF NOT EXISTS accounts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      uid TEXT NOT NULL UNIQUE,
      device_id TEXT,
      pass_key TEXT,
      status TEXT DEFAULT 'PENDING',
      session_token TEXT,
      last_heartbeat INTEGER,
      created_at INTEGER DEFAULT (strftime('%s', 'now')),
      updated_at INTEGER DEFAULT (strftime('%s', 'now')),
      blocked_reason TEXT,
      approved_at INTEGER,
      approved_by TEXT
    )
  `);

  // Device history (for tracking device changes)
  db.exec(`
    CREATE TABLE IF NOT EXISTS device_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      uid TEXT NOT NULL,
      device_id TEXT NOT NULL,
      action TEXT NOT NULL,
      timestamp INTEGER DEFAULT (strftime('%s', 'now')),
      ip_address TEXT,
      FOREIGN KEY (uid) REFERENCES accounts(uid)
    )
  `);

  // Signals table
  db.exec(`
    CREATE TABLE IF NOT EXISTS signals (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      signal_type TEXT NOT NULL,
      asset TEXT DEFAULT 'QUOTEX',
      expiry TEXT DEFAULT '1m',
      confidence REAL,
      indicators TEXT,
      created_at INTEGER DEFAULT (strftime('%s', 'now')),
      candle_time INTEGER NOT NULL,
      trend TEXT,
      rsi REAL,
      ema_trend TEXT
    )
  `);

  // Admin users table
  db.exec(`
    CREATE TABLE IF NOT EXISTS admin_users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      created_at INTEGER DEFAULT (strftime('%s', 'now')),
      last_login INTEGER
    )
  `);

  // Activity log
  db.exec(`
    CREATE TABLE IF NOT EXISTS activity_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      action TEXT NOT NULL,
      uid TEXT,
      admin_user TEXT,
      details TEXT,
      timestamp INTEGER DEFAULT (strftime('%s', 'now'))
    )
  `);

  // Create indexes
  db.exec(`
    CREATE INDEX IF NOT EXISTS idx_accounts_uid ON accounts(uid);
    CREATE INDEX IF NOT EXISTS idx_accounts_device ON accounts(device_id);
    CREATE INDEX IF NOT EXISTS idx_accounts_status ON accounts(status);
    CREATE INDEX IF NOT EXISTS idx_signals_time ON signals(candle_time);
    CREATE INDEX IF NOT EXISTS idx_device_history_uid ON device_history(uid);
  `);

  console.log('✅ Database initialized successfully');
}

// Initialize on first load
initializeDatabase();

module.exports = { db, initializeDatabase };