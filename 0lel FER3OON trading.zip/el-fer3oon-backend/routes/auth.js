const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const { db } = require('../config/database');
const { sessionAuth } = require('../middleware/auth');

// Register/Login with UID and Device ID
router.post('/register', (req, res) => {
  try {
    const { uid, device_id } = req.body;
    
    if (!uid || !device_id) {
      return res.status(400).json({ 
        error: 'UID and Device ID are required' 
      });
    }

    // Check if account exists
    const existing = db.prepare('SELECT * FROM accounts WHERE uid = ?').get(uid);
    
    if (!existing) {
      // Create new account
      const stmt = db.prepare(`
        INSERT INTO accounts (uid, device_id, status) 
        VALUES (?, ?, 'PENDING')
      `);
      
      stmt.run(uid, device_id);
      
      // Log device registration
      db.prepare(`
        INSERT INTO device_history (uid, device_id, action) 
        VALUES (?, ?, 'REGISTERED')
      `).run(uid, device_id);
      
      return res.json({
        status: 'PENDING',
        message: 'Account created. Waiting for admin approval.',
        uid,
        device_id
      });
    }
    
    // Account exists - verify device
    if (existing.device_id !== device_id) {
      // Different device detected
      db.prepare(`
        UPDATE accounts SET status = 'BLOCKED', blocked_reason = ? 
        WHERE uid = ?
      `).run('Multiple device login attempt', uid);
      
      // Log violation
      db.prepare(`
        INSERT INTO device_history (uid, device_id, action) 
        VALUES (?, ?, 'BLOCKED_MULTI_DEVICE')
      `).run(uid, device_id);
      
      return res.status(403).json({
        status: 'BLOCKED',
        error: 'Account blocked: Multiple device access detected',
        message: 'Contact support to reset your device'
      });
    }
    
    // Check account status
    if (existing.status === 'BLOCKED') {
      return res.status(403).json({
        status: 'BLOCKED',
        error: 'Account is blocked',
        reason: existing.blocked_reason || 'Contact support',
        message: 'Your account has been blocked. Contact support.'
      });
    }
    
    if (existing.status === 'PENDING') {
      return res.json({
        status: 'PENDING',
        message: 'Account is pending approval',
        uid,
        device_id
      });
    }
    
    // Account is APPROVED - generate session token
    if (existing.status === 'APPROVED' && existing.pass_key) {
      const sessionToken = jwt.sign(
        { 
          uid, 
          device_id,
          pass_key: existing.pass_key 
        },
        process.env.JWT_SECRET,
        { expiresIn: '7d' }
      );
      
      // Update session token and heartbeat
      db.prepare(`
        UPDATE accounts 
        SET session_token = ?, last_heartbeat = strftime('%s', 'now')
        WHERE uid = ?
      `).run(sessionToken, uid);
      
      return res.json({
        status: 'APPROVED',
        session_token: sessionToken,
        pass_key: existing.pass_key,
        message: 'Login successful'
      });
    }
    
    res.status(400).json({ error: 'Invalid account state' });
    
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Verify PassKey
router.post('/verify-passkey', (req, res) => {
  try {
    const { uid, device_id, pass_key } = req.body;
    
    if (!uid || !device_id || !pass_key) {
      return res.status(400).json({ error: 'Missing required fields' });
    }
    
    const account = db.prepare(`
      SELECT * FROM accounts 
      WHERE uid = ? AND device_id = ? AND pass_key = ?
    `).get(uid, device_id, pass_key);
    
    if (!account) {
      return res.status(401).json({ 
        error: 'Invalid credentials',
        verified: false 
      });
    }
    
    if (account.status !== 'APPROVED') {
      return res.status(403).json({ 
        error: 'Account not approved',
        status: account.status,
        verified: false
      });
    }
    
    // Generate session token
    const sessionToken = jwt.sign(
      { uid, device_id, pass_key },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );
    
    // Update session
    db.prepare(`
      UPDATE accounts 
      SET session_token = ?, last_heartbeat = strftime('%s', 'now')
      WHERE uid = ?
    `).run(sessionToken, uid);
    
    res.json({
      verified: true,
      status: 'APPROVED',
      session_token: sessionToken
    });
    
  } catch (error) {
    console.error('Verify error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Heartbeat - keep session alive
router.post('/heartbeat', sessionAuth, (req, res) => {
  try {
    const { uid, device_id } = req.user;
    
    const account = db.prepare(`
      SELECT * FROM accounts WHERE uid = ? AND device_id = ?
    `).get(uid, device_id);
    
    if (!account) {
      return res.status(404).json({ error: 'Account not found' });
    }
    
    if (account.status === 'BLOCKED') {
      return res.status(403).json({ 
        error: 'Account blocked',
        status: 'BLOCKED'
      });
    }
    
    // Update heartbeat
    db.prepare(`
      UPDATE accounts 
      SET last_heartbeat = strftime('%s', 'now')
      WHERE uid = ?
    `).run(uid);
    
    res.json({ 
      status: account.status,
      heartbeat: 'OK',
      timestamp: Date.now()
    });
    
  } catch (error) {
    console.error('Heartbeat error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Check account status
router.get('/status', sessionAuth, (req, res) => {
  try {
    const { uid } = req.user;
    
    const account = db.prepare(`
      SELECT status, pass_key, last_heartbeat, blocked_reason 
      FROM accounts WHERE uid = ?
    `).get(uid);
    
    if (!account) {
      return res.status(404).json({ error: 'Account not found' });
    }
    
    res.json({
      status: account.status,
      has_passkey: !!account.pass_key,
      last_heartbeat: account.last_heartbeat,
      blocked_reason: account.blocked_reason
    });
    
  } catch (error) {
    console.error('Status check error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;