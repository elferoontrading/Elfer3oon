const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const { db } = require('../config/database');
const { adminAuth } = require('../middleware/auth');

// Admin login
router.post('/login', (req, res) => {
  try {
    const { username, password } = req.body;
    
    // Check against environment variables (simple auth)
    if (username === process.env.ADMIN_USERNAME && 
        password === process.env.ADMIN_PASSWORD) {
      
      const token = jwt.sign(
        { username, isAdmin: true },
        process.env.JWT_SECRET,
        { expiresIn: '24h' }
      );
      
      // Log admin login
      db.prepare(`
        INSERT INTO activity_log (action, admin_user) 
        VALUES ('ADMIN_LOGIN', ?)
      `).run(username);
      
      return res.json({
        success: true,
        token,
        username
      });
    }
    
    res.status(401).json({ error: 'Invalid credentials' });
    
  } catch (error) {
    console.error('Admin login error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get all accounts
router.get('/accounts', adminAuth, (req, res) => {
  try {
    const status = req.query.status;
    let query = 'SELECT * FROM accounts ORDER BY created_at DESC';
    let params = [];
    
    if (status) {
      query = 'SELECT * FROM accounts WHERE status = ? ORDER BY created_at DESC';
      params = [status];
    }
    
    const accounts = db.prepare(query).all(...params);
    
    res.json({
      accounts: accounts.map(acc => ({
        ...acc,
        last_heartbeat_human: acc.last_heartbeat 
          ? new Date(acc.last_heartbeat * 1000).toISOString()
          : null,
        created_at_human: new Date(acc.created_at * 1000).toISOString()
      }))
    });
    
  } catch (error) {
    console.error('Get accounts error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get dashboard stats
router.get('/dashboard', adminAuth, (req, res) => {
  try {
    const stats = db.prepare(`
      SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'PENDING' THEN 1 ELSE 0 END) as pending,
        SUM(CASE WHEN status = 'APPROVED' THEN 1 ELSE 0 END) as approved,
        SUM(CASE WHEN status = 'BLOCKED' THEN 1 ELSE 0 END) as blocked,
        SUM(CASE WHEN last_heartbeat > strftime('%s', 'now', '-5 minutes') THEN 1 ELSE 0 END) as active_now
      FROM accounts
    `).get();
    
    const recentActivity = db.prepare(`
      SELECT * FROM activity_log 
      ORDER BY timestamp DESC 
      LIMIT 10
    `).all();
    
    const recentSignals = db.prepare(`
      SELECT * FROM signals 
      ORDER BY candle_time DESC 
      LIMIT 5
    `).all();
    
    res.json({
      stats,
      recent_activity: recentActivity,
      recent_signals: recentSignals.map(s => ({
        ...s,
        indicators: JSON.parse(s.indicators || '{}'),
        timestamp_human: new Date(s.candle_time * 1000).toISOString()
      }))
    });
    
  } catch (error) {
    console.error('Dashboard error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Approve account
router.post('/accounts/:uid/approve', adminAuth, (req, res) => {
  try {
    const { uid } = req.params;
    
    const account = db.prepare('SELECT * FROM accounts WHERE uid = ?').get(uid);
    
    if (!account) {
      return res.status(404).json({ error: 'Account not found' });
    }
    
    // Generate PassKey
    const passKey = crypto.randomBytes(16).toString('hex');
    
    db.prepare(`
      UPDATE accounts 
      SET status = 'APPROVED', 
          pass_key = ?, 
          approved_at = strftime('%s', 'now'),
          approved_by = ?
      WHERE uid = ?
    `).run(passKey, req.admin.username, uid);
    
    // Log action
    db.prepare(`
      INSERT INTO activity_log (action, uid, admin_user, details) 
      VALUES ('ACCOUNT_APPROVED', ?, ?, ?)
    `).run(uid, req.admin.username, `PassKey: ${passKey}`);
    
    res.json({
      success: true,
      uid,
      pass_key: passKey,
      status: 'APPROVED',
      message: 'Account approved successfully'
    });
    
  } catch (error) {
    console.error('Approve error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Block account
router.post('/accounts/:uid/block', adminAuth, (req, res) => {
  try {
    const { uid } = req.params;
    const { reason } = req.body;
    
    const account = db.prepare('SELECT * FROM accounts WHERE uid = ?').get(uid);
    
    if (!account) {
      return res.status(404).json({ error: 'Account not found' });
    }
    
    db.prepare(`
      UPDATE accounts 
      SET status = 'BLOCKED', 
          blocked_reason = ?,
          session_token = NULL
      WHERE uid = ?
    `).run(reason || 'Blocked by admin', uid);
    
    // Log action
    db.prepare(`
      INSERT INTO activity_log (action, uid, admin_user, details) 
      VALUES ('ACCOUNT_BLOCKED', ?, ?, ?)
    `).run(uid, req.admin.username, reason || 'Manual block');
    
    res.json({
      success: true,
      uid,
      status: 'BLOCKED',
      message: 'Account blocked successfully'
    });
    
  } catch (error) {
    console.error('Block error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Reset device (allow new device login)
router.post('/accounts/:uid/reset-device', adminAuth, (req, res) => {
  try {
    const { uid } = req.params;
    
    const account = db.prepare('SELECT * FROM accounts WHERE uid = ?').get(uid);
    
    if (!account) {
      return res.status(404).json({ error: 'Account not found' });
    }
    
    // Clear device and session
    db.prepare(`
      UPDATE accounts 
      SET device_id = NULL, 
          session_token = NULL,
          status = 'PENDING',
          last_heartbeat = NULL
      WHERE uid = ?
    `).run(uid);
    
    // Log action
    db.prepare(`
      INSERT INTO device_history (uid, device_id, action) 
      VALUES (?, ?, 'DEVICE_RESET_BY_ADMIN')
    `).run(uid, account.device_id);
    
    db.prepare(`
      INSERT INTO activity_log (action, uid, admin_user, details) 
      VALUES ('DEVICE_RESET', ?, ?, ?)
    `).run(uid, req.admin.username, `Old device: ${account.device_id}`);
    
    res.json({
      success: true,
      uid,
      message: 'Device reset successfully. User can login from new device.'
    });
    
  } catch (error) {
    console.error('Reset device error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get account details
router.get('/accounts/:uid', adminAuth, (req, res) => {
  try {
    const { uid } = req.params;
    
    const account = db.prepare('SELECT * FROM accounts WHERE uid = ?').get(uid);
    
    if (!account) {
      return res.status(404).json({ error: 'Account not found' });
    }
    
    const deviceHistory = db.prepare(`
      SELECT * FROM device_history 
      WHERE uid = ? 
      ORDER BY timestamp DESC
    `).all(uid);
    
    res.json({
      account: {
        ...account,
        last_heartbeat_human: account.last_heartbeat 
          ? new Date(account.last_heartbeat * 1000).toISOString()
          : null,
        created_at_human: new Date(account.created_at * 1000).toISOString()
      },
      device_history: deviceHistory.map(d => ({
        ...d,
        timestamp_human: new Date(d.timestamp * 1000).toISOString()
      }))
    });
    
  } catch (error) {
    console.error('Get account details error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Delete account
router.delete('/accounts/:uid', adminAuth, (req, res) => {
  try {
    const { uid } = req.params;
    
    // Delete from all tables
    db.prepare('DELETE FROM device_history WHERE uid = ?').run(uid);
    db.prepare('DELETE FROM accounts WHERE uid = ?').run(uid);
    
    // Log action
    db.prepare(`
      INSERT INTO activity_log (action, uid, admin_user) 
      VALUES ('ACCOUNT_DELETED', ?, ?)
    `).run(uid, req.admin.username);
    
    res.json({
      success: true,
      message: 'Account deleted successfully'
    });
    
  } catch (error) {
    console.error('Delete account error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get activity log
router.get('/activity-log', adminAuth, (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 50;
    
    const logs = db.prepare(`
      SELECT * FROM activity_log 
      ORDER BY timestamp DESC 
      LIMIT ?
    `).all(limit);
    
    res.json({
      logs: logs.map(log => ({
        ...log,
        timestamp_human: new Date(log.timestamp * 1000).toISOString()
      }))
    });
    
  } catch (error) {
    console.error('Activity log error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;