const express = require('express');
const router = express.Router();
const { db } = require('../config/database');
const { sessionAuth } = require('../middleware/auth');

// Get account info
router.get('/info', sessionAuth, (req, res) => {
  try {
    const { uid } = req.user;
    
    const account = db.prepare(`
      SELECT uid, device_id, status, pass_key, last_heartbeat, created_at
      FROM accounts WHERE uid = ?
    `).get(uid);
    
    if (!account) {
      return res.status(404).json({ error: 'Account not found' });
    }
    
    res.json({
      account: {
        uid: account.uid,
        device_id: account.device_id,
        status: account.status,
        has_passkey: !!account.pass_key,
        last_heartbeat: account.last_heartbeat,
        created_at: account.created_at
      }
    });
    
  } catch (error) {
    console.error('Get account info error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;