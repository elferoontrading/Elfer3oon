const express = require('express');
const router = express.Router();
const { db } = require('../config/database');
const { sessionAuth } = require('../middleware/auth');
const { generateSignal, calculateIndicators } = require('../services/signalGenerator');

// Get latest signal (for approved accounts only)
router.get('/latest', sessionAuth, (req, res) => {
  try {
    const { uid, device_id } = req.user;
    
    // Verify account is approved
    const account = db.prepare(`
      SELECT * FROM accounts 
      WHERE uid = ? AND device_id = ? AND status = 'APPROVED'
    `).get(uid, device_id);
    
    if (!account) {
      return res.status(403).json({ 
        error: 'Account not approved or invalid',
        locked: true
      });
    }
    
    // Get current minute timestamp (aligned to candle start)
    const now = new Date();
    const candleTime = new Date(
      now.getFullYear(),
      now.getMonth(),
      now.getDate(),
      now.getHours(),
      now.getMinutes(),
      0,
      0
    );
    const candleTimestamp = Math.floor(candleTime.getTime() / 1000);
    
    // Check if signal already exists for this minute
    let signal = db.prepare(`
      SELECT * FROM signals 
      WHERE candle_time = ? 
      ORDER BY id DESC LIMIT 1
    `).get(candleTimestamp);
    
    // Generate new signal if doesn't exist
    if (!signal) {
      const newSignal = generateSignal(candleTimestamp);
      
      const stmt = db.prepare(`
        INSERT INTO signals (
          signal_type, asset, expiry, confidence, 
          indicators, candle_time, trend, rsi, ema_trend
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      
      const result = stmt.run(
        newSignal.signal_type,
        newSignal.asset,
        newSignal.expiry,
        newSignal.confidence,
        JSON.stringify(newSignal.indicators),
        candleTimestamp,
        newSignal.trend,
        newSignal.rsi,
        newSignal.ema_trend
      );
      
      signal = db.prepare('SELECT * FROM signals WHERE id = ?').get(result.lastInsertRowid);
    }
    
    // Update heartbeat
    db.prepare(`
      UPDATE accounts 
      SET last_heartbeat = strftime('%s', 'now')
      WHERE uid = ?
    `).run(uid);
    
    res.json({
      signal: signal.signal_type,
      asset: signal.asset,
      expiry: signal.expiry,
      confidence: signal.confidence,
      trend: signal.trend,
      rsi: signal.rsi,
      ema_trend: signal.ema_trend,
      timestamp: signal.candle_time,
      generated_at: signal.created_at,
      indicators: JSON.parse(signal.indicators || '{}')
    });
    
  } catch (error) {
    console.error('Signal error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get signal history
router.get('/history', sessionAuth, (req, res) => {
  try {
    const { uid } = req.user;
    const limit = parseInt(req.query.limit) || 20;
    
    // Verify account
    const account = db.prepare(`
      SELECT * FROM accounts WHERE uid = ? AND status = 'APPROVED'
    `).get(uid);
    
    if (!account) {
      return res.status(403).json({ error: 'Account not approved' });
    }
    
    const signals = db.prepare(`
      SELECT * FROM signals 
      ORDER BY candle_time DESC 
      LIMIT ?
    `).all(limit);
    
    res.json({
      signals: signals.map(s => ({
        signal: s.signal_type,
        asset: s.asset,
        confidence: s.confidence,
        trend: s.trend,
        rsi: s.rsi,
        timestamp: s.candle_time,
        indicators: JSON.parse(s.indicators || '{}')
      }))
    });
    
  } catch (error) {
    console.error('History error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get signal statistics
router.get('/stats', sessionAuth, (req, res) => {
  try {
    const { uid } = req.user;
    
    // Verify account
    const account = db.prepare(`
      SELECT * FROM accounts WHERE uid = ? AND status = 'APPROVED'
    `).get(uid);
    
    if (!account) {
      return res.status(403).json({ error: 'Account not approved' });
    }
    
    const stats = db.prepare(`
      SELECT 
        COUNT(*) as total_signals,
        SUM(CASE WHEN signal_type = 'UP' THEN 1 ELSE 0 END) as up_signals,
        SUM(CASE WHEN signal_type = 'DOWN' THEN 1 ELSE 0 END) as down_signals,
        AVG(confidence) as avg_confidence
      FROM signals
      WHERE candle_time > strftime('%s', 'now', '-24 hours')
    `).get();
    
    res.json({
      last_24h: {
        total: stats.total_signals || 0,
        up: stats.up_signals || 0,
        down: stats.down_signals || 0,
        avg_confidence: stats.avg_confidence ? stats.avg_confidence.toFixed(2) : 0
      }
    });
    
  } catch (error) {
    console.error('Stats error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;