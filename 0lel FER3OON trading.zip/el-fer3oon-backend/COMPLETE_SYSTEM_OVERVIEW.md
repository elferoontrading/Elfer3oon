# 📋 Complete System Overview - EL FER3OON TRADING

## 🎯 System Components

This is a complete professional trading application with three main components:

1. **Flutter Mobile App** (Android) - User interface
2. **Node.js Backend API** - Business logic & data management
3. **Web Admin Panel** - Account management dashboard

---

## 📁 Complete File List

### Backend Files (Node.js)

#### Root Files
```
📄 package.json              - Dependencies and scripts
📄 .env                      - Environment configuration (SECRET!)
📄 server.js                 - Main server entry point
📄 README.md                 - Backend documentation
📄 QUICK_START.md           - Setup guide
```

#### Config
```
📁 config/
  └── 📄 database.js        - SQLite database setup & schema
```

#### Middleware
```
📁 middleware/
  └── 📄 auth.js            - Authentication middleware (API Key, JWT, Admin)
```

#### Routes
```
📁 routes/
  ├── 📄 auth.js            - Registration, login, heartbeat, status
  ├── 📄 accounts.js        - Account information
  ├── 📄 signals.js         - Signal generation & history
  └── 📄 admin.js           - Admin panel endpoints
```

#### Services
```
📁 services/
  └── 📄 signalGenerator.js - Advanced signal logic (RSI, EMA, Trends)
```

#### Scripts
```
📁 scripts/
  └── 📄 initDatabase.js    - Database initialization script
```

#### Public (Admin Panel)
```
📁 public/
  └── 📁 admin/
      └── 📄 index.html     - Complete admin dashboard (HTML/CSS/JS)
```

#### Database (Auto-generated)
```
📁 database/
  └── 📄 el_fer3oon.db      - SQLite database (created automatically)
```

---

### Flutter App Files (Already Created)

#### Root
```
📄 pubspec.yaml             - Dependencies
📄 README.md                - App documentation
```

#### Main
```
📁 lib/
  └── 📄 main.dart          - App entry point
```

#### Services
```
📁 lib/services/
  ├── 📄 storage_service.dart  - Local storage (UID, Device ID, Status)
  ├── 📄 auth_service.dart     - State management
  └── 📄 api_service.dart      - Backend API integration (NEW)
```

#### Screens
```
📁 lib/screens/
  ├── 📄 splash_screen.dart
  ├── 📄 welcome_screen.dart
  ├── 📄 registration_gate_screen.dart
  ├── 📄 uid_input_screen.dart
  ├── 📄 pending_screen.dart
  └── 📄 main_trading_screen.dart
```

#### Widgets
```
📁 lib/widgets/
  └── 📄 animated_background.dart
```

#### Android
```
📁 android/app/src/main/
  └── 📄 AndroidManifest.xml
```

---

## 🔄 System Flow

```
┌─────────────────────────────────────────────────────────────┐
│                     USER JOURNEY                             │
└─────────────────────────────────────────────────────────────┘

1. User Opens App
   └─> Splash Screen (3 sec)
       └─> Welcome Screen
           └─> Registration Gate
               └─> UID Input
                   │
                   ├─> API Call: POST /api/auth/register
                   │   └─> Backend: Create account (Status: PENDING)
                   │       └─> Save to database
                   │
                   └─> Navigate to Pending Screen
                       └─> Shows: UID + Device ID
                       └─> Button: Contact Support
                       └─> Auto-check status every 30s

2. Admin Approves (Admin Panel)
   └─> Admin logs into panel
       └─> Views pending accounts
           └─> Clicks "Approve"
               └─> Backend generates PassKey
                   └─> Status = APPROVED
                       └─> PassKey shown to admin

3. User Gets PassKey (via Telegram)
   └─> Admin sends PassKey to user
       └─> App auto-detects approval
           └─> Navigates to Trading Screen
               └─> WebView unlocks
               └─> Signal button activates

4. Trading Session
   └─> Every 30 seconds: Heartbeat sent
   │   └─> POST /api/auth/heartbeat
   │       └─> Backend checks: same device?
   │           ├─> ✅ Same device: OK
   │           └─> ❌ Different device: BLOCK account
   │
   └─> Every minute: Signal available
       └─> User clicks "GET SIGNAL"
           └─> GET /api/signals/latest
               └─> Backend:
                   ├─> Verifies session
                   ├─> Generates signal (RSI, EMA, Trend)
                   └─> Returns: UP/DOWN + Confidence
```

---

## 🔐 Security Architecture

### Multi-Layer Protection

```
Layer 1: API Key
├─ Mobile app must send X-API-Key header
├─ Prevents unauthorized API access
└─ Configured in .env

Layer 2: Session Token (JWT)
├─ Generated after approval
├─ Expires in 7 days
├─ Contains: UID, Device ID, PassKey
└─ Required for all protected endpoints

Layer 3: Device Enforcement
├─ Device ID linked to account
├─> Automatic BLOCK if different device detected
└─> Only admin can reset device

Layer 4: Heartbeat Monitoring
├─ App sends heartbeat every 30s
├─ Backend tracks last_heartbeat
└─ Detects inactive/dead sessions

Layer 5: Admin Authentication
├─ Separate JWT for admin panel
├─ Username + Password from .env
└─ Activity logging for all actions
```

---

## 📊 Database Schema

### Tables Overview

```sql
accounts
├── id (PK)
├── uid (UNIQUE)
├── device_id
├── pass_key
├── status (PENDING/APPROVED/BLOCKED)
├── session_token
├── last_heartbeat
├── created_at
├── updated_at
├── blocked_reason
├── approved_at
└── approved_by

signals
├── id (PK)
├── signal_type (UP/DOWN)
├── asset (QUOTEX)
├── expiry (1m)
├── confidence (50-95)
├── indicators (JSON)
├── candle_time (aligned to minute)
├── trend (BULLISH/BEARISH/NEUTRAL)
├── rsi (0-100)
├── ema_trend
└── created_at

device_history
├── id (PK)
├── uid (FK)
├── device_id
├── action (REGISTERED/BLOCKED/RESET)
├── timestamp
└── ip_address

activity_log
├── id (PK)
├── action (ACCOUNT_APPROVED/BLOCKED/etc)
├── uid
├── admin_user
├── details
└── timestamp
```

---

## 🎯 API Endpoints Summary

### Public (No Auth)
```
GET  /health                    - Health check
```

### App Endpoints (Requires API Key)
```
POST /api/auth/register         - Register/Login
POST /api/auth/verify-passkey   - Verify PassKey
POST /api/auth/heartbeat        - Keep session alive (+ JWT)
GET  /api/auth/status           - Check status (+ JWT)
GET  /api/accounts/info         - Get account info (+ JWT)
GET  /api/signals/latest        - Get current signal (+ JWT)
GET  /api/signals/history       - Get signal history (+ JWT)
GET  /api/signals/stats         - Get statistics (+ JWT)
```

### Admin Endpoints
```
POST   /api/admin/login                    - Admin login
GET    /api/admin/dashboard                - Dashboard stats
GET    /api/admin/accounts                 - List accounts
GET    /api/admin/accounts/:uid            - Account details
POST   /api/admin/accounts/:uid/approve    - Approve account
POST   /api/admin/accounts/:uid/block      - Block account
POST   /api/admin/accounts/:uid/reset-device - Reset device
DELETE /api/admin/accounts/:uid            - Delete account
GET    /api/admin/activity-log             - View activity log
```

---

## 🚀 Deployment Checklist

### Pre-Deployment

- [ ] All backend files created in correct folders
- [ ] All Flutter files integrated
- [ ] Dependencies installed (`npm install`)
- [ ] Database initialized (`npm run init-db`)
- [ ] `.env` configured with secure values
- [ ] Admin credentials changed
- [ ] API Key changed
- [ ] JWT Secret changed

### Backend Deployment

- [ ] Server accessible (VPS/Cloud)
- [ ] Node.js 16+ installed
- [ ] Port 3000 open in firewall
- [ ] PM2 installed for process management
- [ ] Environment variables configured
- [ ] Database backups scheduled
- [ ] SSL certificate configured (production)
- [ ] Nginx reverse proxy setup (optional)
- [ ] Monitoring configured

### Flutter App Deployment

- [ ] API URL updated in `api_service.dart`
- [ ] API Key updated in `api_service.dart`
- [ ] HTTP package added to `pubspec.yaml`
- [ ] API integration tested
- [ ] Heartbeat implemented
- [ ] Signal fetching implemented
- [ ] Error handling added
- [ ] Build APK/AAB for release

### Testing Checklist

- [ ] User can register (UID + Device ID saved)
- [ ] Account appears as PENDING in admin panel
- [ ] Admin can approve account
- [ ] PassKey generated and displayed
- [ ] App detects approval automatically
- [ ] WebView unlocks after approval
- [ ] Signals load every minute
- [ ] Heartbeat maintains session
- [ ] Multi-device login blocked automatically
- [ ] Admin can block/reset accounts
- [ ] Activity log records actions

---

## 📈 Signal Generation Logic

### Technical Indicators Used

```javascript
RSI (Relative Strength Index)
├─ Period: 14
├─ Range: 0-100
├─ < 30: Oversold (Signal: UP)
├─ > 70: Overbought (Signal: DOWN)
└─ 45-55: Neutral (rely on trend)

EMA (Exponential Moving Average)
├─ EMA 12 (short term)
├─ EMA 26 (long term)
├─ EMA12 > EMA26: Bullish trend
└─ EMA12 < EMA26: Bearish trend

Trend Detection
├─ Compares EMA with current price
├─ BULLISH: Price above EMAs
├─ BEARISH: Price below EMAs
└─ NEUTRAL: Mixed signals

Candle Patterns
├─ Strong Bull: Large green body
├─ Strong Bear: Large red body
├─ Hammer: Long lower shadow (bullish)
├─ Shooting Star: Long upper shadow (bearish)
└─ Neutral: Small body or doji

Confidence Score (50-95%)
├─ Base: 50%
├─ +10%: EMA trend confirmation
├─ +20%: RSI oversold/overbought
├─ +15%: Trend alignment
├─ +15%: Candle pattern
├─ +10%: Multiple confirmations
└─ Capped at 95% (never 100%)
```

---

## 🛠️ Customization Options

### Change Signal Logic
Edit `services/signalGenerator.js`:
```javascript
// Adjust RSI thresholds
if (rsi < 25) // More aggressive (default: 30)

// Add more indicators
const macd = calculateMACD(prices);

// Change confidence weights
confidence += 25; // Instead of 20
```

### Change Heartbeat Interval
In `.env`:
```env
HEARTBEAT_TIMEOUT=45000  # 45 seconds (default: 60s)
```

In Flutter app:
```dart
Timer.periodic(Duration(seconds: 45), ...);
```

### Add New Account Status
In `database.js`, add to schema, then update logic in routes.

### Change Session Expiry
In `routes/auth.js`:
```javascript
jwt.sign({...}, secret, { expiresIn: '14d' }); // 14 days instead of 7
```

---

## 📞 Support & Maintenance

### Regular Tasks

**Daily:**
- Monitor server logs
- Check active sessions
- Review blocked accounts

**Weekly:**
- Backup database
- Review signal accuracy
- Check system resources

**Monthly:**
- Update dependencies
- Security audit
- Performance optimization

### Common Maintenance Commands

```bash
# View logs
pm2 logs el-fer3oon

# Restart server
pm2 restart el-fer3oon

# Database backup
cp database/el_fer3oon.db backups/backup-$(date +%Y%m%d).db

# View active sessions
sqlite3 database/el_fer3oon.db "SELECT COUNT(*) FROM accounts WHERE last_heartbeat > strftime('%s', 'now', '-5 minutes');"

# Clear old signals (keep last 7 days)
sqlite3 database/el_fer3oon.db "DELETE FROM signals WHERE candle_time < strftime('%s', 'now', '-7 days');"
```

---

## 🎓 Learning Resources

### Technologies Used
- **Backend**: Node.js, Express.js
- **Database**: SQLite (better-sqlite3)
- **Auth**: JWT (jsonwebtoken), bcryptjs
- **Frontend**: Flutter/Dart
- **Admin Panel**: Vanilla HTML/CSS/JavaScript

### Documentation Links
- Node.js: https://nodejs.org/docs
- Express.js: https://expressjs.com
- SQLite: https://www.sqlite.org/docs.html
- Flutter: https://docs.flutter.dev
- JWT: https://jwt.io

---

## 📝 Version History

**v1.0.0** - Initial Release
- ✅ Complete backend API
- ✅ Admin panel dashboard
- ✅ Advanced signal generation
- ✅ Single device enforcement
- ✅ Session management
- ✅ Activity logging
- ✅ Flutter app integration

---

## 🔮 Future Roadmap

### Phase 2 (Coming Soon)
- [ ] Real-time WebSocket signals
- [ ] Email notifications
- [ ] Telegram bot integration
- [ ] Machine learning signal optimization
- [ ] Multi-asset support
- [ ] Performance analytics
- [ ] Mobile admin app

### Phase 3 (Planned)
- [ ] Payment integration
- [ ] Subscription tiers
- [ ] Advanced risk management
- [ ] Copy trading features
- [ ] Social features
- [ ] Automated testing suite

---

## ⚖️ License & Legal

**Proprietary Software**
- All rights reserved
- Not for redistribution
- Commercial use only with permission
- Source code confidential

---

## 📧 Contact

**Technical Support:**
- Telegram: [@EL_FER3OON](http://t.me/EL_FER3OON)

**System Status:**
- Check: `http://your-server/health`

---

**Built with ❤️ for professional traders**

**EL FER3OON TRADING © 2026**