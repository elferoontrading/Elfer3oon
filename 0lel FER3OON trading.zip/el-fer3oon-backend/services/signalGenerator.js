// Advanced Signal Generation with Technical Indicators

function calculateRSI(prices, period = 14) {
  if (prices.length < period) return 50; // Default neutral
  
  let gains = 0;
  let losses = 0;
  
  for (let i = 1; i <= period; i++) {
    const change = prices[i] - prices[i - 1];
    if (change > 0) gains += change;
    else losses += Math.abs(change);
  }
  
  const avgGain = gains / period;
  const avgLoss = losses / period;
  
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  const rsi = 100 - (100 / (1 + rs));
  
  return rsi;
}

function calculateEMA(prices, period = 12) {
  if (prices.length < period) return prices[prices.length - 1];
  
  const multiplier = 2 / (period + 1);
  let ema = prices.slice(0, period).reduce((a, b) => a + b) / period;
  
  for (let i = period; i < prices.length; i++) {
    ema = (prices[i] - ema) * multiplier + ema;
  }
  
  return ema;
}

function detectTrend(prices) {
  if (prices.length < 20) return 'NEUTRAL';
  
  const ema12 = calculateEMA(prices, 12);
  const ema26 = calculateEMA(prices, 26);
  const currentPrice = prices[prices.length - 1];
  
  if (ema12 > ema26 && currentPrice > ema12) return 'BULLISH';
  if (ema12 < ema26 && currentPrice < ema12) return 'BEARISH';
  
  return 'NEUTRAL';
}

function analyzeCandlePattern(open, high, low, close) {
  const body = Math.abs(close - open);
  const range = high - low;
  const upperShadow = high - Math.max(open, close);
  const lowerShadow = Math.min(open, close) - low;
  
  // Bullish patterns
  if (close > open && body > range * 0.7) return { pattern: 'STRONG_BULL', signal: 'UP' };
  if (close > open && lowerShadow > body * 2) return { pattern: 'HAMMER', signal: 'UP' };
  
  // Bearish patterns
  if (close < open && body > range * 0.7) return { pattern: 'STRONG_BEAR', signal: 'DOWN' };
  if (close < open && upperShadow > body * 2) return { pattern: 'SHOOTING_STAR', signal: 'DOWN' };
  
  return { pattern: 'NEUTRAL', signal: 'NEUTRAL' };
}

function generateMockPriceData() {
  // In production, this would fetch real market data
  // For now, generate realistic mock data
  const prices = [];
  let price = 1000 + Math.random() * 100;
  
  for (let i = 0; i < 50; i++) {
    const change = (Math.random() - 0.5) * 5;
    price += change;
    prices.push(price);
  }
  
  return prices;
}

function generateSignal(candleTimestamp) {
  // Generate mock price data
  const prices = generateMockPriceData();
  const currentPrice = prices[prices.length - 1];
  const previousPrice = prices[prices.length - 2];
  
  // Calculate indicators
  const rsi = calculateRSI(prices);
  const trend = detectTrend(prices);
  const ema12 = calculateEMA(prices, 12);
  const ema26 = calculateEMA(prices, 26);
  
  // Mock OHLC for current candle
  const open = previousPrice;
  const close = currentPrice;
  const high = Math.max(open, close) + Math.random() * 2;
  const low = Math.min(open, close) - Math.random() * 2;
  
  const candlePattern = analyzeCandlePattern(open, high, low, close);
  
  // Signal decision logic
  let signal = 'UP';
  let confidence = 50;
  let emaTrend = 'NEUTRAL';
  
  // EMA crossover
  if (ema12 > ema26) {
    emaTrend = 'BULLISH';
    confidence += 10;
  } else if (ema12 < ema26) {
    emaTrend = 'BEARISH';
    confidence -= 10;
  }
  
  // RSI analysis
  if (rsi < 30) {
    signal = 'UP'; // Oversold
    confidence += 20;
  } else if (rsi > 70) {
    signal = 'DOWN'; // Overbought
    confidence += 20;
  } else if (rsi >= 45 && rsi <= 55) {
    // Neutral RSI, rely on trend
    if (trend === 'BULLISH') {
      signal = 'UP';
      confidence += 15;
    } else if (trend === 'BEARISH') {
      signal = 'DOWN';
      confidence += 15;
    }
  }
  
  // Candle pattern influence
  if (candlePattern.signal === 'UP') {
    signal = 'UP';
    confidence += 15;
  } else if (candlePattern.signal === 'DOWN') {
    signal = 'DOWN';
    confidence += 15;
  }
  
  // Trend confirmation
  if (trend === 'BULLISH' && signal === 'UP') confidence += 10;
  if (trend === 'BEARISH' && signal === 'DOWN') confidence += 10;
  
  // Normalize confidence
  confidence = Math.min(95, Math.max(50, confidence));
  
  return {
    signal_type: signal,
    asset: 'QUOTEX',
    expiry: '1m',
    confidence: confidence,
    trend: trend,
    rsi: parseFloat(rsi.toFixed(2)),
    ema_trend: emaTrend,
    indicators: {
      rsi: parseFloat(rsi.toFixed(2)),
      ema12: parseFloat(ema12.toFixed(2)),
      ema26: parseFloat(ema26.toFixed(2)),
      candle_pattern: candlePattern.pattern,
      trend: trend
    }
  };
}

function calculateIndicators(prices) {
  return {
    rsi: calculateRSI(prices),
    ema12: calculateEMA(prices, 12),
    ema26: calculateEMA(prices, 26),
    trend: detectTrend(prices)
  };
}

module.exports = {
  generateSignal,
  calculateIndicators,
  calculateRSI,
  calculateEMA,
  detectTrend
};